<?php
/**
 * The header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="content">
 *
 * @package understrap
 */

$container = get_theme_mod( 'understrap_container_type' );
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/font-awesome/css/font-awesome.min.css">
	<meta name="apple-mobile-web-app-title" content="<?php bloginfo( 'name' ); ?> - <?php bloginfo( 'description' ); ?>">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/physible.css" />
	<script src="<?php echo get_template_directory_uri() ?>/js/jquery-3.3.1.min.js"></script>
	<script src="<?php echo get_template_directory_uri() ?>/libs/OwlCarousel2-2.3.4/owl.carousel.min.js"></script>
	<script src="<?php echo get_template_directory_uri() ?>/libs/jwp/jwplayer.js"></script>
	<script src="<?php echo get_template_directory_uri() ?>/libs/jwp/jwp.js"></script>
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/libs/OwlCarousel2-2.3.4/assets/owl.carousel.min.css" />
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/libs/OwlCarousel2-2.3.4/assets/owl.theme.default.min.css" />
	<link rel="icon" 
      type="image/png" 
      href="<?php echo get_template_directory_uri(); ?>/assets/img/favico.png">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
		<?php if ( 'container' == $contaziner ) : ?>
			<div class="container">
		<?php else : ?>
			<div class="container-fluid navbar-dark">
		<?php endif; ?>
				<div class="row desktopOnly">
					<div class="col-md-5 col-lg-5 col-sm-5 col-xs-5 align-items-center menu-section">
							<?php wp_nav_menu(
											array(
												'theme_location'  => 'primary-right',
												
												'walker'          => new physible_WP_Submenu_Navwalker(),
											)
						); ?>
					</div>
					<div class="col-md-2 col-lg-2 col-sm-2 col-xs-2 align-items-center menu-section">
						<!-- Your site title as branding in the menu -->
						<?php if ( ! has_custom_logo() ) { ?>

						<?php if ( is_front_page() && is_home() ) : ?>

							<h1 class="navbar-brand mb-0"><a rel="home" href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>"><?php bloginfo( 'name' ); ?></a></h1>
							
						<?php else : ?>

							<a class="navbar-brand" rel="home" href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>"><?php bloginfo( 'name' ); ?></a>

						<?php endif; ?>


						<?php } else {
						the_custom_logo();
						} ?><!-- end custom logo -->
					</div>
					<div class="col-md-5 col-lg-5 col-sm-5 col-xs-5 align-items-center menu-section">
 								<?php wp_nav_menu(
									array(
										'theme_location'  => 'primary-left',
										'walker'          => new physible_WP_Submenu_Navwalker(),
									)
								 ); ?>

					</div>
				</div>
				<div class="mobileOnly">
					<div class="row mobile-menu">
						<a href="#" class="inline-item" id="mobile-menu-toggle">
							<i class="fa fa-bars fa-lg"></i>
						</a>
						<!-- Your site title as branding in the menu -->
						<?php if ( ! has_custom_logo() ) { ?>

						<?php if ( is_front_page() && is_home() ) : ?>

							<h1 class="navbar-brand mb-0"><a rel="home" href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>"><?php bloginfo( 'name' ); ?></a></h1>
							
						<?php else : ?>

							<a class="navbar-brand" rel="home" href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>"><?php bloginfo( 'name' ); ?></a>

						<?php endif; ?>


						<?php } else {
						the_custom_logo();
						} ?><!-- end custom logo -->
						<div class="mobile-menu-items hide" id="mobile-menu-items">
						<a href="#" class="close-btn" id="close-btn">
							<i class="fa fa-close fa-lg">
							
							</i>
						</a>
							<?php wp_nav_menu(
									array(
										'theme_location'  => 'primary-right',
										'walker'  => new Walker_Quickstart_Menu()
									)
							); ?>
					</div>
					</div>

				</div>
				
				<!-- The WordPress Menu goes here -->
				
			</div><!-- .container(-fluid) -->

								 