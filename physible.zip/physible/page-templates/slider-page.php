<?php
/**
 * Template Name: Slider Page
 *
 * Template for displaying a page without sidebar even if a sidebar widget is published.
 *
 * @package understrap
 */
	get_header();
?>
<div class="container">
	<div class="wrapper" id="full-width-page-wrapper">

		<div class="<?php echo esc_attr( $container ); ?>" id="content">

			<div class="row">

				<div class="col-md-12 content-area" id="primary">

					<main class="site-main" id="main" role="main">

						<?php while ( have_posts() ) : the_post(); 
						the_content();
							$values = rwmb_meta( 'physible-select_category' );
							foreach ( $values as $value ):
								$cat_posts = get_posts(array(
									'category' => $value)
								);?>
								<h2 class="slider-title"><?php echo get_the_category_by_ID($value); ?></h2>
							<div class="video-slider">
								<a class="nav nav-right desktopOnly" onClick="next(<?php echo $value?>)">
									<img src="<?php echo get_template_directory_uri(); ?>/assets/img/nav.png"/>
								</a>
								<a class="nav nav-left desktopOnly" onClick="prev(<?php echo $value?>)">
									<img src="<?php echo get_template_directory_uri(); ?>/assets/img/nav.png"/>
								</a>
								<div class="owl-carousel owl-theme" id="owl-slider-<?php echo $value ?>">
									<?php
									foreach($cat_posts as $post): setup_postdata($post);?>
										<div class="item">
											<a href="<?php the_permalink() ?>">
												<img src="<?php echo get_the_post_thumbnail_url(get_the_ID(),'full');?>" class="responsive-img" />
												<div class="item-details">
													<p class="course-title"><?php the_title();?></p>
													<p>مدرس:
														<?php
															echo rwmb_meta('physible-course_tutor');
														?>
													</p>
												</div>
											</a>
										</div>
									<?php 
										endforeach;
									?>
								</div>
							</div>
							<?php
							endforeach;?>
						<?php endwhile; // end of the loop. ?>

					</main><!-- #main -->

				</div><!-- #primary -->

			</div><!-- .row end -->
		<script>
			var owl = $('.owl-carousel');
			owl.owlCarousel({
			loop:true,
			margin:10,
			rtl: true,
			responsive:{
					0:{
						items:3
					},
					600:{
						items:4
					},
					1000:{
						items:5
					}
				}
			});
			function next(id) {
				var owl = $("#owl-slider-" + id);
				owl.trigger('next.owl.carousel');
			}
			function prev(id) {
				var owl = $("#owl-slider-" + id);
				owl.trigger('prev.owl.carousel', [300]);
			}
		</script>
		</div><!-- Container end -->

	</div><!-- Wrapper end -->
</div>

<?php get_footer(); ?>
