<?php
/**
 * Template Name: Post List Page
 *
 * Template for displaying a page without sidebar even if a sidebar widget is published.
 *
 * @package understrap
 */

get_header();
?>


<?php while ( have_posts() ) : the_post(); ?>
    <?php the_content(); ?>
	<div class="container post-list" id="content">
        <div class="row">
            <h1 class="post-list-title"><?php the_title() ?></h1>
        </div>
        <?php
            $target_slug = get_post_meta( get_the_ID(), 'physible-cat_slug', true ); 
        ?>
        <?php
            global $post;
            $args = array( 'numberposts' => 1000, 'category_name' => $target_slug );
            $posts = get_posts( $args );
            foreach( $posts as $post ): setup_postdata($post); 
        ?>
            
        <div class="row">
            <div class="desktopOnly col-md-1 avatar-holder">
                <?php echo get_avatar(get_the_author_meta('ID')); ?> 
            </div>
            <div class="col-xs-12 col-sm-12 col-md-9 post">
                    <a href="<?php the_permalink() ?>">
                    <div class="post-head">
                        <img src="<?php echo get_template_directory_uri() ?>/assets/img/icon_notebook.png" class="post-icon"/>		
                        <h2>
                            <?php the_title(); ?>
                        </h2>
                        <div class="numbers">
                            <img src="<?php echo get_template_directory_uri() ?>/assets/img/icon_comment.png" class="post-icon"/>		
                            <h2><?php echo get_comments_number( get_the_ID() );?></h2>
                            <img src="<?php echo get_template_directory_uri() ?>/assets/img/icon_view.png" class="post-icon"/>		
                            <h2><?php echo getPostViews(get_the_ID()); ?></h2>
                        </div>
                    </div>
                    <div class="post-avatar">
                        <img class="responsive-img" src="<?php echo get_the_post_thumbnail_url(get_the_ID(),'full');?>" />
                        <p><?php echo get_post_meta( get_the_ID(), 'physible-post_shortdesc', true );?></p>
                    </div>
                    <div class="post-foot">
                        <p class="tags">
                            <?php
                                $posttags = get_the_tags();
                                if ($posttags) {
                                    echo '<img src="' . get_template_directory_uri() . '/assets/img/icon_tag.png" class="post-icon" />';
                                    $numItems = count($posttags);
                                    $i = 0;
                                    foreach($posttags as $tag) {
                                        echo '<a href="/tag/'. $tag->slug . '">'.$tag->name . '</a>';
                                        if( ++$i != $numItems) {
                                            echo "، ";
                                        }
                                    }
                                }
                            ?>
                        </p>
                        <div class="numbers">
                            <a href="<?php the_permalink() ?>">
                                ادامه مطلب    
                            </a>
                        </div>
                    </div>
                </a>
            </div>
            <div class="desktopOnly col-md-2"></div>
        </div>
        <?php endforeach; ?>
	</div><!-- Container end -->
<?php endwhile; // end of the loop. ?>



<?php get_footer(); ?>
