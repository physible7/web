<?php
/**
 * The template for displaying all single posts.
 *
 * @package understrap
 */

get_header();
while ( have_posts() ) : 
	setPostViews(get_the_ID());				
	the_post();
?>
<div class="wrapper" id="single-wrapper">
	<header class="entry-header">
		<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
	</header><!-- .entry-header -->
	<div class="container small-padding" id="content" tabindex="-1">

		<div class="row no-margin">
				<?php

					if ( has_post_format( 'video' )) {
						get_template_part('posts/post', 'video');
					} else {
						get_template_part('posts/post', 'normal');
					}
					
				?>
		</div><!-- #primary -->
		<div class="row no-margin about-tutor">
			<div class="inline-item avatar-holder">
				<?php echo get_avatar(get_the_author_meta('ID')); ?> 
			</div>
			<div class="inline-item bio-holder">
				<p><?php echo the_author_meta( 'display_name');?></p>
				<p><?php echo nl2br(get_the_author_meta('description'));?></p>
			</div>
		</div>
		<div class="line"></div>
		<div class="row no-margin">
		<?php
					// If comments are open or we have at least one comment, load up the comment template.
					if ( comments_open() || get_comments_number() ) :
						comments_template();
					endif;
					?>
		</div>
	</div><!-- .row -->

</div><!-- Container end -->

</div><!-- Wrapper end -->
<?php endwhile; // end of the loop. ?>

<?php get_footer(); ?>
