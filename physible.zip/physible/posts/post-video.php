<div class="container">
    <div class="row video-playlist">
        <div class="col-md-8 video-player">
        <div id="video-player"></div>
        <script type="text/javascript">
            function playFile(source1,source2) {
                var playerInstance = jwplayer("video-player");
                if(source2 != ""){
                    playerInstance.setup({
                        sources: [{ 
                                file: source1,
                                label: "HD"
                            },{
                                file: source2,
                                label: "SD"
                            },
                        ],
                        aspectratio: "16:9",
                        width: "100%",
                        image: "<?php echo get_the_post_thumbnail_url(get_the_ID(),'full'); ?>"
                    });
                } else {
                    playerInstance.setup({
                        file: source1,
                        aspectratio: "16:9",
                        width: "100%",
                    });
                }
            }
        </script>
        </div>
        <div class="col-md-4 video-list">
            <div class="video-list-head">
                <h3>جلسات</h3>
            </div>
            <div class="video-list-content">
                <?php 
                    $videos = rwmb_meta( 'physible-video_list_fieldset' );
                    $index = 0;
                    foreach ($videos as $video):
                        $index++;
                ?>
                <div class="video">
                    <p>جلسه <?php echo $index . ': ' . $video['name']; ?></p>
                    <a onclick="playFile('<?php echo $video['file_720'];?>','<?php echo $video['file_480'] ?>')">مشاهده آنلاین</a>
                    <br />
                    <?php if($video['file_720']):?>
                        <a href="<?php echo $video['file_720'];?>" class="download-link" download> دانلود کیفیت 720 </a>
                    <?php endif; ?>
                    <?php if($video['file_480']):?>
                        <a href="<?php echo $video['file_480'];?>" class="download-link" download> دانلود کیفیت 480 </a>
                    <?php endif; ?>
                    <?php if($index==1) {?>
                        <script>
                            playFile('<?php echo $video['file_720'];?>','<?php echo $video['file_480'] ?>');
                        </script>    
                    <?php } ?>
                </div>
                    <?php endforeach;?>
            </div>
        </div>
    </div>
    <div class="row video-descriptions">
        <p>توضیحات</p>
        <?php the_content(); ?>
    </div>

</div><!-- #post-## -->
