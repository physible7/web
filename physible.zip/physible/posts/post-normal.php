<div>
	<div class="entry-content">

		<?php the_content(); ?>

	</div><!-- .entry-content -->

</div><!-- #post-## -->
