<?php
/**
 * Single post partial template.
 *
 * @package understrap
 */

?>
