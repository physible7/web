<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package understrap
 */

$the_theme = wp_get_theme();
$container = get_theme_mod( 'understrap_container_type' );
?>

<?php get_sidebar( 'footerfull' ); ?>

<div class="wrapper" id="wrapper-footer">
	<footer class="site-footer footer" id="colophon">
		<div class="container-fluid">

			<div class="row">
				<div class="col-md-4">
					<div class="site-info">
					<br />						
						
						<center>
							درباره ما
						</center>
						<br />						
						<p>
							ما در فیزیبل، تلفیقی از تلاش، استعداد و تجربه
							آموزشی گروهمون رو تا حد امکان بصورت “رایگان”،
							در اختیار دانش‌آموزان سراسر کشور قرار می‌دهیم.
							<br />
							<br />
							برای تحقق امکان بهره‌مندی تمامی دانش‌آموزان از 
							آموزش عادلانه و خوب، از همه‌ی عزیزانی که توانایی
							علمی و عملی برای یاری رساندن در این هدف را دارند،
							دعوت به همکاری می‌شود.
						</p>
					</div><!-- .site-info -->
				</div><!--col end -->
				<div class="col-md-8 footer-nav desktopOnly">
					<?php wp_nav_menu(
							array(
								'theme_location'  => 'footer-menu',
							)
					);
					$options = get_option( 'phs_settings' );
					?>
				</div><!--col end -->
				
			</div><!-- row end -->
			<div class="row copyright">
				<ul>
					<li class="inline-item">
						<img src="<?php echo get_template_directory_uri(); ?>/assets/img/footer-logo.png" class="footer-logo"/>
						<p>
							گروه آموزشی فیزیبل
						</p>
					</li>
					<li class="inline-item">کلیه حقوق مادی و معنوی این سایت متعلق به گروه آموزشی فیزیبل می‌باشد. </li>
					<li class="inline-item">
						<a href="phone:+989127379194">
							<img class="footer-icon-3x" src="<?php echo get_template_directory_uri() ?>/assets/img/footer-phone.png"/>
						</a>
					</li>
					<li class="inline-item">
						<a href="mailto:info@phyisible.ir">
							<img class="footer-icon" src="<?php echo get_template_directory_uri() ?>/assets/img/footer-mail.png" />
						</a>
					</li>
					<li class="inline-item">
						<a href="<?php echo $options['phs_tlg_link']; ?>" target="_blank">
							<img class="footer-icon" src="<?php echo get_template_directory_uri() ?>/assets/img/footer-teleg.png" />
						</a>
					</li>
					<li class="inline-item">
						<a href="<?php echo $options['phs_ig_link']; ?>" target="_blank">
							<img class="footer-icon" src="<?php echo get_template_directory_uri() ?>/assets/img/footer-ig.png" />
						</a>
					</li>
				</ul>
			</div>
		</div><!-- container end -->
	</footer><!-- #colophon -->
</div><!-- wrapper end -->

</div><!-- #page we need this extra closing tag here -->

<?php wp_footer(); ?>
<script>
// Select all links with hashes
$('a[href*="#"]')
  // Remove links that don't actually link to anything
  .not('[href="#"]')
  .not('[href="#0"]')
  .click(function(event) {
    // On-page links
    if (
      location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') 
      && 
      location.hostname == this.hostname
    ) {
      // Figure out element to scroll to
      var target = $(this.hash);
      target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
      // Does a scroll target exist?
      if (target.length) {
        // Only prevent default if animation is actually gonna happen
        event.preventDefault();
        $('html, body').animate({
          scrollTop: target.offset().top
        }, 1000, function() {
          // Callback after animation
          // Must change focus!
          var $target = $(target);
          $target.focus();
          if ($target.is(":focus")) { // Checking if the target was focused
            return false;
          } else {
            $target.attr('tabindex','-1'); // Adding tabindex for elements not focusable
            $target.focus(); // Set focus again
          };
        });
      }
    }
  });
	$("#mobile-menu-toggle").click(function(){
		$('#mobile-menu-items').toggleClass('hide');
	})
	$("#close-btn").click(function(){
		$('#mobile-menu-items').addClass('hide');
	})
  </script>
</body>

</html>

