<?php
/**
 * Understrap functions and definitions
 *
 * @package understrap
 */

/**
 * Initialize theme default settings
 */
require get_template_directory() . '/inc/theme-settings.php';

/**
 * Theme setup and custom theme supports.
 */
require get_template_directory() . '/inc/setup.php';

/**
 * Register widget area.
 */
require get_template_directory() . '/inc/widgets.php';

/**
 * Enqueue scripts and styles.
 */
require get_template_directory() . '/inc/enqueue.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/pagination.php';

/**
 * Custom functions that act independently of the theme templates.
 */
require get_template_directory() . '/inc/extras.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Custom Comments file.
 */
require get_template_directory() . '/inc/custom-comments.php';

/**
 * Load Jetpack compatibility file.
 */
require get_template_directory() . '/inc/jetpack.php';

/**
 * Load custom WordPress nav walker.
 */
require get_template_directory() . '/inc/bootstrap-wp-navwalker.php';

/**
 * Load WooCommerce functions.
 */
require get_template_directory() . '/inc/woocommerce.php';

/**
 * Load Editor functions.
 */
require get_template_directory() . '/inc/editor.php';

function physible_course_box( $meta_boxes ) {
	$prefix = 'physible-';

	$meta_boxes[] = array(
		'id' => 'course_info',
		'title' => esc_html__( 'Course Fields', 'Course Fields' ),
		'post_types' => array( 'post' ),
		'context' => 'advanced',
		'priority' => 'default',
		'autosave' => true,
		'fields' => array(
			array(
				'id' => $prefix . 'course_date',
				'type' => 'text',
				'name' => esc_html__( 'تاریخ دوره', 'Course Fields' ),
			),
			array(
				'id' => $prefix . 'course_time',
				'type' => 'text',
				'name' => esc_html__( 'ساعت دوره', 'Course Fields' ),
			),
			array(
				'id' => $prefix . 'course_location',
				'type' => 'text',
				'name' => esc_html__( 'محل دوره', 'Course Fields' ),
			),
			array(
				'id' => $prefix . 'course_tutor',
				'type' => 'text',
				'name' => esc_html__( 'مدرس دوره', 'Course Fields' ),
			),
			array(
				'id' => $prefix . 'course_tutor_resume',
				'type' => 'url',
				'name' => esc_html__( 'آدرس رزومه مدرس', 'Course Fields' ),
			),
			array(
				'id' => $prefix . 'course_chair',
				'type' => 'number',
				'name' => esc_html__( 'ظرفیت دوره', 'Course Fields' ),
				'step' => '1',
			),
		),
	);

	return $meta_boxes;
}
add_filter( 'rwmb_meta_boxes', 'physible_course_box' );

function physible_test_box( $meta_boxes ) {
	$prefix = 'physible-';

	$meta_boxes[] = array(
		'id' => 'test_info',
		'title' => esc_html__( 'Test Fields', 'Test Fields' ),
		'post_types' => array( 'post' ),
		'context' => 'advanced',
		'priority' => 'default',
		'autosave' => true,
		'fields' => array(
			array(
				'id' => $prefix . 'test_date',
				'type' => 'text',
				'name' => esc_html__( 'تاریخ آزمون', 'test Fields' ),
			),
			array(
				'id' => $prefix . 'test_time',
				'type' => 'text',
				'name' => esc_html__( 'زمان آزمون', 'test Fields' ),
			),
			array(
				'id' => $prefix . 'test_location',
				'type' => 'text',
				'name' => esc_html__( 'محل آزمون', 'test Fields' ),
			),
			array(
				'id' => $prefix . 'test_syllabus',
				'type' => 'text',
				'name' => esc_html__( 'مباحث آزمون', 'test Fields' ),
			),
			array(
				'id' => $prefix . 'test_q_num',
				'type' => 'text',
				'name' => esc_html__( 'سوالات آزمون', 'test Fields' ),
				'step' => '1',
			),
		),
	);

	return $meta_boxes;
}
add_filter( 'rwmb_meta_boxes', 'physible_test_box' );

function physible_promo_box( $meta_boxes ) {
	$prefix = 'physible-';

	$meta_boxes[] = array(
		'id' => 'promo_info',
		'title' => esc_html__( 'Promo Fields', 'Promo Fields' ),
		'post_types' => array( 'post', 'page' ),
		'context' => 'advanced',
		'priority' => 'default',
		'autosave' => true,
		'fields' => array(
			array(
				'id' => $prefix . 'promo_pic',
				'type' => 'file_input',
				'name' => esc_html__( 'Promo Select', 'Promo Fields' ),
				'force_delete' => false,
				'max_file_uploads' => '1',
			),
		),
	);

	return $meta_boxes;
}
add_filter( 'rwmb_meta_boxes', 'physible_promo_box' );

function physible_post_list_box( $meta_boxes ) {
	$prefix = 'physible-';

	$meta_boxes[] = array(
		'id' => 'post_list',
		'title' => esc_html__( 'Post List', 'Post List' ),
		'post_types' => array( 'page' ),
		'context' => 'advanced',
		'priority' => 'default',
		'autosave' => true,
		'fields' => array(
			array(
				'id' => $prefix . 'cat_slug',
				'type' => 'text',
				'name' => esc_html__( 'Category Slug', 'Post List' ),
			),
		),
	);

	return $meta_boxes;
}
add_filter( 'rwmb_meta_boxes', 'physible_post_list_box' );

function physible_cat_list_box( $meta_boxes ) {
	$prefix = 'physible-';
	$cats = array();
	$categories=  get_categories(); 
	foreach ($categories as $category) {
		$cat_name = $category->cat_name;
		$cat_id = $category->cat_ID;
		$cats += array($cat_id => $cat_name);
	}
	// var_dump($cats);
	$meta_boxes[] = array(
		'id' => 'slider-cat-sel',
		'title' => esc_html__( 'Slider Category Selector', 'slider-category-selector' ),
		'post_types' => array( 'page' ),
		'context' => 'advanced',
		'priority' => 'default',
		'autosave' => false,
		'fields' => array(
			array(
				'id' => $prefix . 'select_category',
				'name' => esc_html__( 'Select Category', 'slider-category-selector' ),
				'type' => 'select',
				'placeholder' => esc_html__( 'Select an Item', 'slider-category-selector' ),
				'options' => $cats,
				'multiple' => true,
			),
		),
		
	);

	return $meta_boxes;
}
add_filter( 'rwmb_meta_boxes', 'physible_cat_list_box' );
function physible_video_list_box( $meta_boxes ) {
	$prefix = 'physible-';

	$meta_boxes[] = array(
		'id' => 'video_list',
		'title' => esc_html__( 'Video List Box', 'Video List Box' ),
		'post_types' => array( 'post' ),
		'context' => 'advanced',
		'priority' => 'default',
		'autosave' => false,
		'fields' => array(
			array(
				'id' => $prefix . 'video_list_fieldset',
				'type' => 'fieldset_text',
				'name' => esc_html__( 'Video List Field Set', 'Video List Box' ),
				'rows' => 1,
				'options' => array(
					'name' => 'نام جلسه',
					'file_480' => '480p فایل',
					'file_720' => '720p فایل',
				),
				'clone' => true,
				'max_clone' => 1000,
				'sort_clone' => true,
				'add_button' => esc_html__( 'بیشتر', 'Video List Box' ),
			),
		),
	);

	return $meta_boxes;
}
add_filter( 'rwmb_meta_boxes', 'physible_video_list_box' );

function getPostViews($postID){
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
        return "0";
    }
    return $count;
}
function setPostViews($postID) {
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        $count = 0;
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
    }else{
        $count++;
        update_post_meta($postID, $count_key, $count);
    }
}
// Remove issues with prefetching adding extra views
remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0);


function physible_post_box( $meta_boxes ) {
	$prefix = 'physible-';

	$meta_boxes[] = array(
		'id' => 'post_data',
		'title' => esc_html__( 'Post Data', 'Post Data' ),
		'post_types' => array( 'post' ),
		'context' => 'advanced',
		'priority' => 'default',
		'autosave' => true,
		'fields' => array(
			array(
				'id' => $prefix . 'post_shortdesc',
				'type' => 'text',
				'name' => esc_html__( 'توضیحات کوتاه', 'Post Data' ),
			),
		),
	);

	return $meta_boxes;
}
add_filter( 'rwmb_meta_boxes', 'physible_post_box' );

add_action( 'admin_menu', 'phs_add_admin_menu' );
add_action( 'admin_init', 'phs_settings_init' );


function phs_add_admin_menu(  ) { 

	add_menu_page( 'Physible Theme', 'Physible Theme', 'manage_options', 'physible_theme', 'phs_options_page' );

}


function phs_settings_init(  ) { 

	register_setting( 'pluginPage', 'phs_settings' );

	add_settings_section(
		'phs_pluginPage_section', 
		__( 'Social Media', 'wordpress' ), 
		'phs_settings_section_callback', 
		'pluginPage'
	);

	add_settings_field( 
		'phs_ig_link', 
		__( 'Instagram Link', 'wordpress' ), 
		'phs_ig_link_render', 
		'pluginPage', 
		'phs_pluginPage_section' 
	);

	add_settings_field( 
		'phs_tlg_link', 
		__( 'Telegram Link', 'wordpress' ), 
		'phs_tlg_link_render', 
		'pluginPage', 
		'phs_pluginPage_section' 
	);


}


function phs_ig_link_render(  ) { 

	$options = get_option( 'phs_settings' );
	?>
	<input type='text' name='phs_settings[phs_ig_link]' value='<?php echo $options['phs_ig_link']; ?>'>
	<?php

}


function phs_tlg_link_render(  ) { 

	$options = get_option( 'phs_settings' );
	?>
	<input type='text' name='phs_settings[phs_tlg_link]' value='<?php echo $options['phs_tlg_link']; ?>'>
	<?php

}


function phs_settings_section_callback(  ) { 

	echo __( 'Social media links go here', 'wordpress' );

}


function phs_options_page(  ) { 

	?>
	<form action='options.php' method='post'>

		<h2>Physible Theme</h2>

		<?php 
		settings_fields( 'pluginPage' );
		do_settings_sections( 'pluginPage' );
		submit_button();
		?>

	</form>
	<?php

}

