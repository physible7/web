<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package understrap
 */

get_header();

$container   = get_theme_mod( 'understrap_container_type' );

?>
<div class="container-fluid home-intro">
	<div class="row">
		<center>
			<img class="physible-home-img-o " src="<?php echo get_template_directory_uri()?>/assets/img/home-pic1.png"/>
			<img src="<?php echo get_template_directory_uri()?>/assets/img/home-pic.png" class="physible-home-img" />
		</center>
		<a href="#part-2" class="physible-home-arrow">
			<img src="<?php echo get_template_directory_uri()?>/assets/img/home-arrow.png" class="physible-home-arrow" />
		</a>
	</div>
</div>
<div class="container-fluid home-2nd" id="part-2">
		<div class="row">
			<p class="sec-head">آموزش به طعم فیزیبل!</p>
			<div class="spacer"></div>
			<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8 text-right">
				<div class="home-blackboard">
					<img class="bb-click" src="<?php echo get_template_directory_uri() ?>/assets/img/click-here.png"/>
					<div class="row">
						<div class="col-xs-6 col-sm-6 col-md-4 col-lg-4 bb-item">
							<a href="/learning-written">
								<img src="<?php echo get_template_directory_uri()?>/assets/img/bb-item-3.png" class="hover-rotate"/>
							</a>
						</div>
						<div class="col-xs-6 col-sm-6 col-md-4 col-lg-4 bb-item">
							<a href="/learning-media">
								<img src="<?php echo get_template_directory_uri()?>/assets/img/bb-item-2.png" class="hover-rotate"/>
							</a>
						</div>
						<div class="col-xs-6 col-sm-6 col-md-4 col-lg-4 bb-item">
							<a href="/learning-courses">
								<img src="<?php echo get_template_directory_uri()?>/assets/img/bb-item-1.png" class="hover-rotate"/>
							</a>
						</div>
						<div class="col-xs-6 col-sm-6 col-md-4 col-lg-4 bb-item">
							<a href="/advise">
								<img src="<?php echo get_template_directory_uri()?>/assets/img/bb-item-6.png" class="hover-rotate"/>
							</a>
						</div>
						<div class="col-xs-6 col-sm-6 col-md-4 col-lg-4 bb-item">
							<a href="/question-bank">
								<img src="<?php echo get_template_directory_uri()?>/assets/img/bb-item-5.png" class="hover-rotate"/>
							</a>
						</div>
						<div class="col-xs-6 col-sm-6 col-md-4 col-lg-4 bb-item">
							<a href="/online-courses">
								<img src="<?php echo get_template_directory_uri()?>/assets/img/bb-item-4.png" class="hover-rotate"/>
							</a>
						</div>
						<br />
					</div>
				</div>
				<img src="<?php echo get_template_directory_uri() ?>/assets/img/bb-wiper.png" class="bb-wiper"/>
			</div>
			<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
				<img src="<?php echo get_template_directory_uri()?>/assets/img/home-lamp.png" class="physible-home-lamp" />			
			</div>
		</div><!-- #primary -->
</div><!-- Container end -->
<div class="container-fluid home-3rd wrapper" id="part-3">
	<img src="<?php echo get_template_directory_uri() ?>/assets/img/bottom-curve.png" class="bottom-curve"/>
	<div class="row">
		<p class="sec-head">با شما میدویم!</p>		
	</div>
	<div class="row">
		<div class="col-sm-12 col-md-5 col-lg-4 col-xs-12 lastest-courses-parent">
			<h4>دوره ها</h4>
			<?php
					global $post;
					$args = array( 'numberposts' => 3, 'category_name' => 'courses' );
					$posts = get_posts( $args );
					foreach( $posts as $post ): setup_postdata($post); 
			?>
				<div class="lastest-courses">
					<img src="<?php echo get_template_directory_uri() ?>/assets/img/courses.png" class="course-badge"/>
					<div class="course">

						<p class="course-title"><?php the_title(); ?></p>
						<p><img class="inline-item" src="<?php echo get_template_directory_uri(); ?>/assets/img/icon_calendar.png" /> <?php echo get_post_meta( get_the_ID(), 'physible-course_date', true ); ?></p>
						<p><img class="inline-item" src="<?php echo get_template_directory_uri(); ?>/assets/img/icon_clock.png" /> <?php echo get_post_meta( get_the_ID(), 'physible-course_time', true ); ?></p>
						<p><img class="inline-item" src="<?php echo get_template_directory_uri(); ?>/assets/img/icon_location.png" /> <?php echo get_post_meta( get_the_ID(), 'physible-course_location', true ); ?></p>
						<p><img class="inline-item" src="<?php echo get_template_directory_uri(); ?>/assets/img/icon_tutor.png" /> <?php echo get_post_meta( get_the_ID(), 'physible-course_tutor', true ); ?> <a href="<?php echo get_post_meta( get_the_ID(), 'physible-course_tutor_resume', true ); ?>"> رزومه و تالیفات </a></p>
						<p><img class="inline-item" src="<?php echo get_template_directory_uri(); ?>/assets/img/icon_chair.png" /> <?php echo get_post_meta( get_the_ID(), 'physible-course_chair', true ); ?>نفر</p>
						<div class="course-enroll">
							<a href="<?php the_permalink() ?>" >
								ثبت نام
							</a>
						</div>

					</div>
				</div>
			<?php endforeach; ?>
			
		</div>
		<div class="col-sm-12 col-md-2 col-lg-4 col-xs-12">
			<img src="<?php echo get_template_directory_uri() ?>/assets/img/physible-run.png" class="responsive-image run-img"/>
		</div>
		<div class="col-sm-12 col-md-5 col-lg-4 col-xs-12 lastest-tests-parent">
		<h4>آزمون ها</h4>
			<?php
					global $post;
					$args = array( 'numberposts' => 3, 'category_name' => 'tests' );
					$posts = get_posts( $args );
					foreach( $posts as $post ): setup_postdata($post); 
			?>
				<div class="lastest-tests">
					<img src="<?php echo get_template_directory_uri() ?>/assets/img/tests.png" class="test-badge"/>
					<div class="test">

						<p class="test-title"><?php the_title(); ?></p>
						<p><img class="inline-item" src="<?php echo get_template_directory_uri(); ?>/assets/img/icon_calendar.png" /> <?php echo get_post_meta( get_the_ID(), 'physible-test_date', true ); ?></p>
						<p><img class="inline-item" src="<?php echo get_template_directory_uri(); ?>/assets/img/icon_clock.png" /> <?php echo get_post_meta( get_the_ID(), 'physible-test_time', true ); ?></p>
						<p><img class="inline-item" src="<?php echo get_template_directory_uri(); ?>/assets/img/icon_qm.png" /> <?php echo get_post_meta( get_the_ID(), 'physible-test_q_num', true ); ?></p>
						<p><img class="inline-item" src="<?php echo get_template_directory_uri(); ?>/assets/img/icon_book.png" /> <?php echo get_post_meta( get_the_ID(), 'physible-test_syllabus', true ); ?></p>
						<p><img class="inline-item" src="<?php echo get_template_directory_uri(); ?>/assets/img/icon_location.png" /> <?php echo get_post_meta( get_the_ID(), 'physible-test_location', true ); ?></p>
						<div class="test-enroll">
							<a href="<?php the_permalink() ?>" >
								شرکت در آزمون
							</a>
						</div>

					</div>
				</div>
			<?php endforeach; ?>
			
		</div>
	</div>
	<img src="<?php echo get_template_directory_uri() ?>/assets/img/top-curve.png" class="top-curve"/>		
</div>
<div class="container-fluid home-4th" id="part-4">
	<div class="container">
		<div class="row">
			<div class="owl-carousel owl-theme">
				<?php
						global $post;
						$args = array( 'numberposts' => 3, 'category_name' => 'promos' );
						$posts = get_posts( $args );
						foreach( $posts as $post ): setup_postdata($post); 
				?>
					<div class="item">
						<a href="<?php the_permalink() ?>">
							<img src="<?php echo get_post_meta( get_the_ID(), 'physible-promo_pic', true ); ?>" class="responsive-img" />
						</a>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	</div>		
</div>

</div><!-- Wrapper end -->
<script>
	$(document).ready(function(){
		$('.physible-home-img-o').addClass('opacity-on');
	})
	$('.owl-carousel').owlCarousel({
    loop:true,
    margin:10,
	rtl: true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
})
</script>
<?php get_footer(); ?>
